# 4. Predictive Maintenance
# Forecasting resource demands, scheduling maintenance tasks based on usage patterns.

# Resource Forecasting & Scheduling (Python)

import numpy as np
from sklearn.linear_model import LinearRegression
import datetime

def forecast_future_resource_usage(data):
    X = np.arange(len(data)).reshape(-1, 1)
    y = np.array(data)
    
    model = LinearRegression()
    model.fit(X, y)
    
    # Predict the next time point
    future = np.array([[len(data) + 1]])
    prediction = model.predict(future)
    
    return prediction[0]

# Example usage data
cpu_usage_data = [45, 50, 55, 60, 58]  # Example CPU usage percentages
predicted_usage = forecast_future_resource_usage(cpu_usage_data)
print(f"Predicted future CPU usage: {predicted_usage}%")

# Schedule predictive maintenance
def schedule_maintenance(predicted_usage):
    if predicted_usage > 75:
        maintenance_date = datetime.datetime.now() + datetime.timedelta(days=1)
        print(f"Scheduled maintenance for {maintenance_date}")
    else:
        print("System resources are stable.")

schedule_maintenance(predicted_usage)
