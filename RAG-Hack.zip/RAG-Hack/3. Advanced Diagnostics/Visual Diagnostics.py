# Visual Diagnostics (Python)

from PIL import Image
import pytesseract

def analyze_screenshot(image_path):
    img = Image.open(image_path)
    text = pytesseract.image_to_string(img)
    return text

# Example usage
screenshot_text = analyze_screenshot("screenshot.png")
print(f"Text detected in screenshot: {screenshot_text}")
